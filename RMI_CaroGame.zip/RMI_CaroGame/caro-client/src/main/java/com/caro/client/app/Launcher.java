package com.caro.client.app;

public class Launcher {
    public static void main(String[] args) {
        // This simple call delegates to the real JavaFX app
        ClientApp.main(args);
    }
}
